/* PROJECT 2, TASK 1 (required)
 * ----------------------------
 * Implement the train and getLabel methods.
 * Use the UnigramFeatureExtractor initially, but
 * later use a feature extractor of your choice.
 */

package classify.student;

import java.util.List;

import util.Counter;
import util.CounterMap;

import classify.general.Classifier;
import classify.general.Example;

public class NaiveBayesClassifier implements Classifier {

  private CounterMap<Object, Object> labelAndFeatureCounts;
  private Counter<Object> labelCounts;
  
  public Object getLabel(Example example) {
    Counter<Object> scores = getLabelScores(example);
    return scores.argmax();
  }

  public Counter<Object> getLabelScores(Example example) {
    Counter<Object> labelScores = new Counter<Object>();
    for (Object label : labelCounts.keySet()) {
      double labelScore = getLogProbabilityOfLabel(example, label);
      labelScores.setCount(label, labelScore);
    }
    return labelScores;
  }
  
  public double getLogProbabilityOfLabel(Example example, Object label) {
    System.err.println("CS 121 STUDENT: implement me as part of TASK 1!");
    return 0.0;
  }

  public void train(List<Example> examples) {
    labelAndFeatureCounts = new CounterMap<Object, Object>();
    labelCounts = new Counter<Object>();
    System.err.println("CS 121 STUDENT: implement me as part of TASK 1!");
  }

  public void testDistributionsValid() {
    System.err.println("CS 121 STUDENT: optional but highly recommended!");
  }
}